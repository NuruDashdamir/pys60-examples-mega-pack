import app2_mod

app2_mod.hello()