import elemlist
print dir(elemlist)