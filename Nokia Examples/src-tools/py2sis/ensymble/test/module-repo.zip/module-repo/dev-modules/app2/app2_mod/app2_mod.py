
def hello():
    print "Hello"