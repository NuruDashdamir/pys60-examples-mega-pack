import e32
import appuifw
import debug
from custom_exceptions import *

VERSION = "0.0.1"

def handle_error(silent = False):
    import sys
    import traceback
    from logger import Logger

    errlog  = Logger("%s\\myapp_error_log.txt" % gv.DATA_PATH)
    errlog.start_trace(time.strftime("%m/%d/%y %H:%M:%S"))
    s = "\n".join(traceback.format_exception(*sys.exc_info()))
    if silent: errlog.writeline("(Silent Error)")
    errlog.writeline(s)
    if not silent:
        appuifw.note(u"An error occured. Details have been logged.")

    if e32.in_emulator(): print s

###################################################################################################
# Base View class, new style views inherit from this class
###################################################################################################
class BaseView(object):
    def __init__(self, parent, title):
        try:
            self.parentview = parent
            self.title = title
        except:
            handle_error()

    def close(self):
        try:
            self.parentview = None
        except:
            handle_error()

    def handle_back(self):
        try:
            self.parentview.activate()
            self.close()
        except:
            handle_error()

    def activate(self):
        try:
            appuifw.app.set_tabs([u"Back to normal"], lambda x: None)
            appuifw.app.title =  u"MyApp - %s" % self.title
            appuifw.app.exit_key_handler = self.handle_back
            appuifw.app.menu = []
        except:
            handle_error()

class App(object):
    def __init__(self):
        try:
            self.lock = e32.Ao_lock()
        except:
            handle_error()

    def activate(self):
        try:
            #at this point we need to quit the app
            self.exit_key_handler()
        except:
            handle_error()

    def run(self):
        try:
            mv = MainView(self, u"MainView")
            mv.activate()

            self.lock.wait()
        except:
            handle_error()


    def exit_key_handler(self):
        try:
            self.lock.signal()
        except:
            handle_error()

    def close(self):
        try:
            appuifw.app.exit_key_handler = None
            if not e32.in_emulator():
                appuifw.app.set_exit()
        except:
            handle_error()



class MainView(BaseView):
    def __init__(self, *args):
        super(MainView,self).__init__(*args)

    def activate(self, *args):
        try:
            super(MainView,self).activate(*args)
          
            appuifw.app.menu = [
                                (u'About',self.handle_about),
                                (u'Exit',self.handle_exit)
								]

            e32.ao_sleep(.3)
            e32.ao_yield()
			appuifw.app.body = appuifw.Text()
			
        except:
            handle_error()

    def handle_exit(self):
        try:
            self.parentview.activate()
        except:
            handle_error()

    def handle_about(self):
        try:
            appuifw.note(unicode("MyApp\nVersion: %s" % VERSION))
        except:
            handle_error()

