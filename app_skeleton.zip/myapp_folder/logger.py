import time

class Logger:
    def __init__(self, log_name):
        self.logfile = log_name

    def write(self, obj):
        log_file = open(self.logfile, 'a')
        log_file.write(obj)
        log_file.close()

    def writelines(self, obj):
        self.write(''.join(list))

    def writeline(self, obj):
        log_file = open(self.logfile, 'a')
        log_file.write(str(obj) + "\r\n")
        log_file.close()

    def start_trace(self, s = "New Trace"):
        self.writeline("**************************************** %s ****************************************" % s)

    def flush(self):
        pass

    def print_exception_trace(self):
        try:
            etype, value, tb = sys.exc_info()
            sys.last_type = etype
            sys.last_value = value
            sys.last_traceback = tb
            tblist = traceback.extract_tb(tb)
            del tblist[:1]
            elist = traceback.format_list(tblist)
            if elist:
                elist.insert(0, "Traceback (most recent call last):\n")
            elist[len(elist):] = traceback.format_exception_only(etype, value)
        finally:
            tblist = tb = None
            for x in elist: self.write(x)

