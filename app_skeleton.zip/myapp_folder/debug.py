import logger
import time

def log(s):

    if env == "pc":
        logfile = "debug.log"
    elif env == "emu":
        logfile = "c:\\data\\myapp_folder\\debug.log"
    elif env == "phone":
        logfile = "e:\\data\\myapp_folder\\debug.log"

    dl = logger.Logger(logfile)
    dl.writeline(time.strftime("%m/%d/%y %H:%M:%S") + '\t' + str(s))

def timeit(s):
    log("%s \t\t%s" % (time.clock(), s) )

def _get_environment():
    """ Possible return values are: pc, emu, phone """
    try:
        import e32
        if e32.in_emulator():
            return "emu"
        else:
            return "phone"
    except:
        return "pc"


try:
    env
except:
    env = _get_environment()