print "MyApp Name"

import appuifw
import sys
import os
import os.path
import e32

try:
    global DATA_PATH
    print "Loading, please wait..."
    e32.ao_sleep(.1)
    e32.ao_yield()
    if e32.in_emulator():
        if e32.pys60_version_info[0] == 1 and e32.pys60_version_info[1] < 5:
            DATA_PATH = 'c:\\python\\myapp_folder\\'
        else:
            DATA_PATH = 'c:\\data\\python\\myapp_folder\\'
    else:
        #create app dir if neccessery
        drive = 'e'
        if os.path.exists('e:'):
            drive = 'e'
            DATA_PATH = 'e:\\data\\myapp_folder'
        elif os.path.exists('c:'):
            drive = 'c'
            DATA_PATH = 'c:\\data\\myapp_folder'
        try:
            os.makedirs('%s:\\data\\myapp_folder' % drive)
        except: pass
        #also add current script path (if we are running from a sis file)
        sys.path.insert(0,os.getcwd()) #not 100% sure this is needed

    if os.path.exists(DATA_PATH) == False:
        appuifw.note(u'Unable to set data directory. Exiting Application.')
        e32.ao_sleep(3)
        appuifw.app.set_exit()
        sys.exit()

    sys.path = sys.path + [DATA_PATH]

    import myapp

    old_title = appuifw.app.title
    exit_handler = appuifw.app.exit_key_handler

    appuifw.app.screen = 'normal'

    menu = appuifw.app.menu

    myApp = myapp.App()
    myApp.run()
    myApp.close()


    if e32.in_emulator():
        appuifw.app.title = old_title
        appuifw.app.exit_key_handler = exit_handler
        appuifw.app.menu = menu
    else:
        appuifw.app.title = old_title
        appuifw.menu = None
except:
    import sys
    import traceback
    import e32
    import appuifw

    if e32.in_emulator():
        if e32.pys60_version_info[0] == 1 and e32.pys60_version_info[1] < 5:
            DATA_PATH = 'c:\\python\\myapp_folder\\'
        else:
            DATA_PATH = 'c:\\data\\python\\myapp_folder\\trunk'
    else:
        DATA_PATH = 'e:\\data\\myapp_folder'
    sys.path = sys.path + [DATA_PATH]

    from logger import Logger

    errlog  = Logger("%s\\myapp_error_log.txt" % DATA_PATH)
    errlog.start_trace()
    appuifw.app.screen = "normal"               # Restore screen to normal size.
    appuifw.app.focus = None                    # Disable focus callback.
    body = appuifw.Text()
    appuifw.app.body = body                     # Create and use a text control.
    exitlock = e32.Ao_lock()
    def exithandler(): exitlock.signal()
    appuifw.app.exit_key_handler = exithandler  # Override softkey handler.
    appuifw.app.menu = [(u"Exit", exithandler)] # Override application menu.
    errlog.writeline("\n".join(traceback.format_exception(*sys.exc_info())))
    body.set(unicode("\n".join(traceback.format_exception(*sys.exc_info()))))
    exitlock.wait()                             # Wait for exit key press.
    appuifw.app.set_exit()
